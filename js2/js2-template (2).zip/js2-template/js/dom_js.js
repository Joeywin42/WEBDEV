//make variable on buttons in greetings.
let amButton = document.getElementById("am");
let pmButton = document.getElementById("pm");
//make variable for variable
let greetingsHeader = document.getElementById("greeting");


//make greeting buttons do stuff
amButton.addEventListener("click", () => {
    greetingsHeader.innerHTML = "Good mornin! :3"
})
pmButton.addEventListener("click", () => {
    greetingsHeader.innerHTML = "Good night :)"
})

//div color stuff variable
let colorClass = document.getElementById("div_color");
let redButton = document.getElementById("red");
let yellowButton = document.getElementById("yellow");
let greenButton = document.getElementById("green");
let blueButton = document.getElementById("blue");

//callback function to change class colour
function changeColor(newColor){
    colorClass.setAttribute('class', newColor);
}
//add function to buttons
redButton.addEventListener("click", () => {
    changeColor("bg_red");
})
yellowButton.addEventListener("click", () => {
    changeColor("bg_yellow");
})
greenButton.addEventListener("click", () => {
    changeColor("bg_green");
})
blueButton.addEventListener("click", () => {
    changeColor("bg_blue");
})
//list thingy variables
let userInput = document.querySelector("#usrInput");
let addButton = document.querySelector("#addBtn");
let myUList = document.querySelector("#myUL");

//event listener
addButton.addEventListener("click", () => {
    //create a new li
    let newLI = document.createElement('li');

    //set the text to the new li
    newLI.textContent = userInput.value;

    //create button
    let deleteButton = document.createElement('button');

    //set the text of button to delete
    deleteButton.textContent = "delete";

    //add event listner to deleteButton
    deleteButton.addEventListener('click', () => {
        newLI.remove();
    })

    //append the delete button
    newLI.appendChild(deleteButton);

    //stick this new thingy onto the ul
    myUList.append(newLI);

    //clear the textbox
    userInput.value = "";
    userInput.focus();

})
